package com.faikturan.sessionlisteners;

import javax.servlet.annotation.WebListener;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

@WebListener
public class ActiveUserTracking implements HttpSessionListener {

	private static int activeUsers;
    public ActiveUserTracking() {
        // TODO Auto-generated constructor stub
    }

    public void sessionCreated(HttpSessionEvent arg0)  { 
         System.out.println("A new Session was created.");
         activeUsers++;
    }

    public void sessionDestroyed(HttpSessionEvent arg0)  { 
         System.out.println("An existing Session was destroyed");
         activeUsers--;
    }
    
    public static int getActiveUserCount(){
    	return activeUsers;
    }
	
}
