package com.faikturan.models;

public abstract class DBUserInfo {

	private String uid;
	private String pwd;
	private String cat;
	
	public DBUserInfo() {
	}

	public DBUserInfo(String userID, String password, String catalog) {
		uid = userID;
		pwd = password;
		cat = catalog;
	}

	public String getUserId() {
		return uid;
	}

	public void setUserId(String value) {
		uid = value;
	}

	public String getPassword() {
		return pwd;
	}

	public void setPassword(String value) {
		pwd = value;
	}

	public String getCatalog() {
		return cat;
	}

	public void setCatalog(String catalog) {
		cat = catalog;
	}
}
